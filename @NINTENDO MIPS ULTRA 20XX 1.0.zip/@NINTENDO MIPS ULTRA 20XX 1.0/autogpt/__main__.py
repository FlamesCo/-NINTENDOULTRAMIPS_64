"""Auto-GPT: A GPT powered AI Assistant"""
import autogpt.app.cli

if __name__ == "__main__":
    autogpt.app.cli.main()
